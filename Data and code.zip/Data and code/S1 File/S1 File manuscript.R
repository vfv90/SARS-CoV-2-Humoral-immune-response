#Title: "Humoral immune response towards SARS-CoV-2 variants of concern and endemic coronaviruses in urban and indigenous populations from Colombia: an explorative seroprevalence study"
#Authors: "Nathalie Fernandez_&_Barbora Kessel"
#Date: 15.10.2022
#R version: 4.1.0
#Description: This script is based on the supplemental material of the manuscript.

# Packages
pacman::p_load("tidyverse", "lm", "glm", "MASS", "gtsummary", "eeptools", "ggplot2", 
               "L1pack", "vcd", "asht", "cowplot", "gridExtra", 
               "ggpubr", "RColorBrewer", "ggpmisc", "gridtext", "irrCAC")

# Read database
data <- read.csv("S1File February 2020-April 2021.csv", header = T, sep = "," ) #with samples collected from feb 2020 
data0 <- read.csv("Main manuscript March-April 2021.csv", header = T, sep = "," ) #with samples collected from March 2021 

# Factorization
data <- data %>% 
  mutate(sex = factor(sex, levels = c("1", "2"), labels = c("female", "male")),
         Population_group = factor(Population_group, levels = c("1", "2", "3"), 
                                   labels = c("Children Population 1", 
                                              "Children Population 2", "Adults Population 2")),
         ELISA_IgG_q = factor (ELISA_IgG_q, level = c("1", "0", "2"), 
                               labels = c("positive", "negative", "borderline")),
         Classification = factor (Classification, level = c("1", "0"),
                                  labels = c("positive", "negative"))) 

#Part I. Table S3
# Seroprevalence by EUROIMMUN
table(data$Population_group, data$ELISA_IgG_q, data$Collection)

#a Crude
#Population 1 February
prop.test(0,154,correct=TRUE)

#Population 1 October-November
prop.test(7,22,correct=TRUE)

#Population 1 March
prop.test(18,80,correct=TRUE)

#Population 2 Children
prop.test(24,82,correct=TRUE) 

#Population 2 Adults
prop.test(78,211,correct=TRUE)

#b Adjusted
#Population 1 February
asht::prevSeSp (0/154, 154, 164/205, 205, 70/72, 72)

#Population 1 October-November
asht::prevSeSp(7/22,22,164/205, 205, 70/72, 72)

#Population 1 March
asht::prevSeSp(18/80,80,164/205, 205, 70/72, 72)

#Population 2 Children
asht::prevSeSp(24/82,82,164/205, 205, 70/72, 72) 

#Population 2 Adults
asht::prevSeSp(78/211,211,164/205, 205, 70/72, 72)

#Part II. Table S4
table(data$Classification, data$ELISA_IgG_q)

#Part III. Figures for S1 File
# Figure S1
#a. Elisa titers and Multicov box plot
A <- ggplot(data = data,
            aes(x = ELISA_IgG_q,
                y = ELISA_IgG_S.CO, fill= Classification))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, 
               na.rm = TRUE, outlier.shape=NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Classification), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  geom_hline(yintercept = 1.1, col = "gray70", size = 0.5, alpha = 0.7)+
  geom_hline(yintercept = 0.8, col = "gray70", size = 0.5, alpha = 0.7)+
  labs(y = "S1 IgG titer (ratio)",
       x = "Anti-SARS-CoV-2 IgG ELISA classification")+
  theme(legend.direction = "none")+
  stat_compare_means(method = "wilcox.test", label = "p.format", na.rm = TRUE,
                     label.y = 15)+
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2
IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00" , "negative" = "#999999"),
                    na.value = 1)+
  theme_classic(base_size = 14)

A1 <-A + theme(legend.position = c(0.85, 0.50)) + labs(title = "A")

#b. S1 vrs Elisa
B <- ggplot(data = data,
       mapping = aes(x = SARS2.S1, y = ELISA_IgG_S.CO)) +
  geom_point(mapping = aes(fill= Classification), size = 2.5, shape=21, 
             alpha = 0.7, na.rm = TRUE)+
  geom_hline(yintercept = 1.1, col = "gray10", size = 0.5, alpha = 0.7)+
  geom_hline(yintercept = 0.8, col = "gray10", size = 0.5, alpha = 0.7)+
  labs(y = "S1 IgG titer (ratio)" ,
       x = "Normalized S1 IgG signal")+
  theme(legend.direction = "vertical")+
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2
IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00", "negative" = "#999999"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", label.y = 15, 
           r.accuracy = 0.01, alternative = "two.sided")+
  facet_grid(~Collection)+
  theme_classic(base_size = 14)

B1 <-B +  theme(legend.position = "none") + labs(title = "B")

grid.arrange(A1, B1, ncol=1, nrow=2, heights = c(1.6,1))

# Figure S2. Levels of SARS-CoV-2 nucleocapsid IgG in reactive samples only (March-April 2021) 
# comparisons between defined groups
my_comparisons <- list( c("Children Population 1", "Children Population 2"), 
                        c("Children Population 2", "Adults Population 2"), 
                        c("Children Population 1", "Adults Population 2"))
# plot
ggplot(data = data0[data0$Classification!= "negative",],
       aes(x = Population_group,
           y = SARS2.N, fill= Population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, 
               outlier.shape=NA)+
  geom_point(aes(fill = Population_group), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25)) +
  geom_hline(yintercept = 1, col = "gray70", size = 0.5)+
  labs(y = "Normalized Nucleocapsid IgG signal",
       x=  NULL)+
  theme(legend.position = "none")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", 
                     method = "wilcox.test")+ 
  stat_compare_means(label.y = 7, paired = TRUE)+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  theme_classic(base_size = 14)

# Program for heatmap 
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("ComplexHeatmap")

library(ComplexHeatmap)

# Defining colors for heatmap
hmcol <- colorRampPalette(c("#cccccc","#888888","#000000","#cc0000","#ff0000"))(20)

# Defining columns for the heatmap based on Endemic coronavirus (Seasonal pattern)
Endemic <- cbind(data$HCoV.OC43.S1, data$HCoV.HKU1.S1, 
                 data$HCoV.NL63.S1, data$HCoV.229E.S1)

# Saving data as a matrix
data3 <- as.matrix(Endemic)

# Saving name of the columns
colnames(data3) <- c("OC43","HKU1", "NL63", "229E")

# Figure S3. Endemcis by collection time
Heatmap(data3, 
             name = "hCoV S1 IgG signal", #title of legend
             split = data$Collection, column_names_gp = gpar(fontsize = 10), 
             col = hmcol, show_row_names = FALSE, cluster_rows = FALSE,
             cluster_columns = FALSE, column_names_rot=0, 
             column_names_centered= TRUE, 
             row_title_rot = 0, row_title_gp = gpar(fontsize = 10))

# Figure S4. Endemcis by Population group
Heatmap(data3, 
             name = "hCoV S1 IgG signal", #title of legend
             split = data$Population_group, column_names_gp = gpar(fontsize = 10), 
             col = hmcol, show_row_names = FALSE, cluster_rows = FALSE,
             cluster_columns = FALSE, column_names_rot=0, 
             column_names_centered= TRUE, 
             row_title_rot = 0, row_title_gp = gpar(fontsize = 10))

# Figure S5. ACE2 binding inhibition (March-April 2021)
#a. WT vs mu
a <- ggplot(data = data0,
            mapping = aes(x = SARS2.RBD.WT_In , y = SARS2.RBD.mu_In)) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 20, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = expression(paste("ACE2 RBD " , mu, " binding inhibition")),
       x = "ACE2 RBD B.1 binding inhibition")+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.position = "none")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  scale_y_continuous(breaks = c(0,20, 40, 60, 80, 100),
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  theme_classic(base_size = 14)

a1 <-a + theme(legend.position  = c(0.90, 0.50), 
               legend.key = element_rect(fill = "transparent", colour = "transparent")) + labs(title = "A")

#b. WT vs delta
b <- ggplot(data = data0,
            mapping = aes(x = SARS2.RBD.WT_In, y =  SARS2.RBD.delta_In)) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 20, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = expression(paste("ACE2 RBD " , delta, " binding inhibition")),
       x = "ACE2 RBD B.1 binding inhibition")+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.position = "none")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  scale_y_continuous(breaks = c(0,20, 40, 60, 80, 100),
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  theme_classic(base_size = 14)

b1 <-b + theme(legend.position  = "None")+ labs(title = "B")

#c. WT vs omicron
c <- ggplot(data = data0,
            mapping = aes(x = SARS2.RBD.WT_In , y = SARS2.RBD.omicron_In)) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 20, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = expression(paste("ACE2 RBD " , omicron, " BA.1 binding inhibition")),
       x = "ACE2 RBD B.1 binding inhibition")+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.direction = "horizontal")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  scale_y_continuous(breaks = c(0,20, 40, 60, 80, 100),
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  theme_classic(base_size = 14)

c1 <- c +
  theme(legend.position = "none") + labs(title = "C")

# to arrange all previuos figures together
grid.arrange(a1, b1, c1, ncol=1, nrow=3, heights = c(2,2,2))

# Figure S6. IgG binding and ACE2 binding inhibition (March-April 2021)
#a. WT
A<-ggplot(data = data0,
          mapping = aes(x = SARS2.RBD.WT_In , y = SARS2.RBD.WT)) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 1, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = "Normalized RBD B.1 IgG signal",
       x = "ACE2 RBD B.1 binding inhibition")+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.direction = "horizontal")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  theme_classic(base_size = 14)

A1 <-A + theme(legend.position  = "None") + labs(title = "A")

#b. delta
B<-ggplot(data = data0,
          mapping = aes(x = SARS2.RBD.delta_In, y = SARS2.RBD.delta )) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 1, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = expression(paste("Normalized RBD " , delta, " IgG signal")),
       x = expression(paste("ACE2 RBD " , delta, " binding inhibition")))+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.direction = "horizontal")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  theme_classic(base_size = 14)

B1 <-B + theme(legend.position  = "None") + labs(title = "C")

#c. omicron
C<-ggplot(data = data0,
          mapping = aes(x = SARS2.RBD.omicron_In, y =  SARS2.RBD.omicron )) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 1, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = expression(paste("Normalized RBD " , omicron,  " BA.1 IgG signal")),
       x = expression(paste("ACE2 RBD " , omicron, " BA.1 binding inhibition")))+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.direction = "horizontal")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  scale_y_continuous(breaks = seq(0, 100, 25), 
                     limits=c(0, 100), 
                     labels = c(0,25, 50, 75, 100))+
  theme_classic(base_size = 14)

C1 <-C + theme(legend.position  = "None") + labs(title = "D")

#d. mu
D<-ggplot(data = data0,
          mapping = aes(x = SARS2.RBD.mu_In , y = SARS2.RBD.mu)) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 1, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = expression(paste("Normalized RBD " , mu, " IgG signal")),
       x = expression(paste("ACE2 RBD " , mu, " binding inhibition")))+
  scale_fill_manual(name = "Population group",
                    labels = c("Children Population 1", "Children Population 2",
                               "Adults Population 2"),
                    values = c("Children Population 1" = "#56B4E9", 
                               "Children Population 2" = "#F0E442",
                               "Adults Population 2" =  "#CC79A7"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.direction = "horizontal")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  scale_y_continuous(breaks = seq(0, 100, 25), 
                     limits=c(0, 100), 
                     labels = c(0,25, 50, 75, 100))+
  theme_classic(base_size = 14)

D1 <- D +
  theme(legend.position  = c(0.7, 0.70), 
        legend.key = element_rect(fill = "transparent", colour = "transparent"))+ 
  labs(title = "B")

# to arrange all previuos figures together
grid.arrange(A1, D1, B1, C1, ncol=2, nrow=2, widths = c(1, 1), 
             heights = c(1,1))
