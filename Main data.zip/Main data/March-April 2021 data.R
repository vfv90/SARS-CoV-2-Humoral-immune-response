#Title: "Humoral immune response to SARS-CoV-2 in urban and indigenous children in Colombia"
#Authors: "Nathalie Fernandez"
#Date: 15.02.2023
#R version: 4.2.2
#Description: This script is based on the main data of the manuscript, which included urban and indigenous children. 

# Packages
pacman::p_load("tidyverse", "lm", "glm", "MASS", "gtsummary", "eeptools", 
               "ggplot2", "L1pack", "vcd", "asht", "cowplot", "gridExtra", 
               "ggpubr", "RColorBrewer", "ggpmisc", "gridtext")

library(tidyverse)
library(dplyr)
library(ggpubr)
library(asht)

# Read database
data0 <- read.csv("Main manuscript March-April 2021.csv", header = T, sep = "," )

# Factorization
data0 <- data0 %>% 
  dplyr::mutate(sex = factor(sex, levels = c("1", "2"), labels = c("female", "male")),
         Population_group = factor(Population_group, levels = c("1", "2"), 
                                   labels = c("Urban children", 
                                              "Indigenous children")),
         ELISA_IgG_q = factor (ELISA_IgG_q, level = c("1", "0", "2"), 
                               labels = c("positive", "negative", "borderline")),
         Classification = factor (Classification, level = c("0", "1"),
                                  labels = c("negative", "positive"))) 
#Part I. Table 1
### Seroprevalence by Multiplex

# multicov-ab by population group
table(data0$Population_group, data0$Classification) 

# sex by population group
table(data0$Population_group, data0$Collection, data0$sex) 

#a Crude
#Urban children
prop.test(17,80,correct=TRUE)

#Indigenous Children
prop.test(28,82,correct=TRUE) 

#b Adjusted
#Urban children
asht::prevSeSp(17/80,80,181/205, 205, 72/72, 72)

#Indigenous Children
asht::prevSeSp(28/82,82,181/205, 205, 72/72, 72) 

### Seroprevalence by EUROIMMUN
table(data0$Population_group, data0$ELISA_IgG_q)

#a Crude
#Urban Children 1 March
prop.test(18,80,correct=TRUE)

#Indigenous Children
prop.test(24,82,correct=TRUE) 

#b Adjusted
#Urban children 1 March
asht::prevSeSp(18/80,80,164/205, 205, 70/72, 72)

#Indigenous children
asht::prevSeSp(24/82,82,164/205, 205, 70/72, 72) 

# Part II. Figures for paper

# define comparisons groups for figures
my_comparisons <- list( c("Urban children", "Indigenous children"))

# Figure 1 (only reactive samples)
#m1. Box plot for RBD
m1 <-ggplot(data = data0[data0$Classification!= "negative",],
            aes(x = Population_group,
                y = SARS2.RBD, fill= Population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, 
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_hline(yintercept = 1, col = "gray", size = 0.5)+
  geom_point(aes(fill = Population_group), 
             size = 1.5, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25)) +
  labs(y = "Normalized RBD IgG signal",
       x = NULL )+
  theme(legend.position = "none")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", 
                               "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  theme_classic(base_size = 14)

m1a <-m1 + theme(legend.position  = "None") + labs(title = "B")

#m2. Box plot for Spike
m2 <-ggplot(data = data0[data0$Classification!= "negative",],
            aes(x = Population_group,
                y = SARS2.Spike, fill= Population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Population_group), 
             size = 1.5, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25)) +
  geom_hline(yintercept = 1, col = "gray", size = 0.5)+
  labs(y = "Normalized Spike Timer IgG signal",
       x =  NULL)+
  theme(legend.position = "none")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", 
                               "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  theme_classic(base_size = 14)

m2b <-m2 + theme(legend.position  = "None") + labs(title = "A")

#m3. Box plot for S1
m3 <-ggplot(data = data0[data0$Classification!= "negative",],
            aes(x = Population_group,
                y = SARS2.S1, fill= Population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Population_group), 
             size = 1.5, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25)) +
  labs(y = "Normalized S1 IgG signal",
       x=  NULL)+
  theme(legend.position = "none")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", 
                               "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  theme_classic(base_size = 14)

m3c <-m3 + theme(legend.position  = "None")+ labs(title = "C")

#m4. Box plot for S2 
m4 <-ggplot(data = data0[data0$Classification!= "negative",],
            aes(x = Population_group,
                y = SARS2.S2, fill= Population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Population_group), 
             size = 1.5, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25)) +
  labs(y = "Normalized S2 domain IgG signal",
       x=  NULL)+
  theme(legend.position = "none")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", 
                               "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  theme_classic(base_size = 14)

m4d <- m4 +
  theme(legend.position = "none") + labs(title = "D")

#m5. Box plot for N and classification by population groups
m5 <-ggplot(data = data0[data0$Classification!= "negative",],
            aes(x = Population_group,
                y = SARS2.N, fill= Population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Population_group), 
             size = 1.5, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25)) +
  labs(y = "Normalized Nucleocapsid IgG signal",
       x=  NULL)+
  theme(legend.direction = "vertical")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", 
                               "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  theme_classic(base_size = 14)

m5e <- m5 +
  theme(legend.position = "none") + labs(title = "E")

legend <- get_legend(m5)

# to arrange all previuos figures together
grid.arrange(m2b, m1a, legend, m3c, m4d, m5e, ncol=3, nrow=2, widths = c(2,2,2), 
             heights = c(2,2))

# Figure 2 (Endemics HCoV)

#a. OC43
A <- ggplot(data = data0,
            aes(x = Population_group,
                y = HCoV.OC43.S1, fill= Classification))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, na.rm = TRUE,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Classification), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  labs(y = "Normalized OC43 S1 IgG signal",
       x = NULL)+
  theme(legend.position = "none")+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+
  stat_compare_means(method = "wilcox.test", label = "p.format", 
                     na.rm = TRUE, label.y = 5, label.x = 1.5)+
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2 
                    IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00" , "negative" = "#999999"),
                    na.value = 1)+
  theme_classic(base_size = 14)

A1 <-A + theme(legend.position  = "None") + labs(title = "OC43 S1", tag= "A")

#b. HKU1
B <- ggplot(data = data0,
            aes(x = Population_group,
                y = HCoV.HKU1.S1, fill= Classification))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, na.rm = TRUE,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Classification), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  labs(y = "Normalized HKU1 S1 IgG signal",
       x = NULL)+
  theme(legend.position = "none")+
  stat_compare_means(method = "wilcox.test", label = "p.format", 
                     na.rm = TRUE, label.y = 6)+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2 IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00" , "negative" = "#999999"),
                    na.value = 1)+
  theme_classic(base_size = 14)

B1 <-B + theme(legend.position  = "None") + labs(title = "HKU1 S1", tag= "B")

#c. NL63
C <- ggplot(data = data0,
            aes(x = Population_group,
                y = HCoV.NL63.S1, fill= Classification))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, na.rm = TRUE,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Classification), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  labs(y = "Normalized NL63 S1 IgG signal",
       x = NULL)+
  theme(legend.position = "none")+
  stat_compare_means(method = "wilcox.test", label = "p.format", 
                     na.rm = TRUE, label.y = 13)+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2 IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00" , "negative" = "#999999"),
                    na.value = 1)+
  theme_classic(base_size = 14)

C1 <-C + theme(legend.position  = "None") + labs(title = "NL63 S1", tag= "C")

#d. 229E
D <- ggplot(data = data0,
            aes(x = Population_group,
                y = HCoV.229E.S1, fill= Classification))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, na.rm = TRUE,
               outlier.shape = NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Classification), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  labs(y = "Normalized 229E S1 IgG signal",
       x = NULL)+
  theme(legend.direction = "vertical")+
  stat_compare_means(method = "wilcox.test", label = "p.format", 
                     na.rm = TRUE, label.y = 6)+
  stat_compare_means(comparisons = my_comparisons, label = "p.format", method = "wilcox.test")+ 
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2
IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00" , "negative" = "#999999"),
                    na.value = 1)+
  theme_classic(base_size = 14)

D1 <- D +
  theme(legend.position = "none") + labs(title = "229E S1", tag= "D")

legend <- get_legend(D)

# to arrange all previuos figures together
grid.arrange(A1, B1, legend, C1, D1, ncol=3, nrow=2, widths = c(1, 1, 0.5), 
             heights = c(1,1))

#Figure 3. IgG binding and ACE2 binding inhibition (March-April 2021)
#WT
ggplot(data = data0,
       mapping = aes(x = SARS2.RBD.WT_In , y = SARS2.RBD.WT)) +
  geom_point(mapping = aes(fill= Population_group), size = 2, shape=21, alpha = 0.7)+
  geom_hline(yintercept = 1, col = "gray70", size = 0.5)+
  geom_vline(xintercept = 20, col = "gray70", size = 0.5)+
  labs(y = "Normalized RBD B.1 IgG signal",
       x = "ACE2 RBD B.1 binding inhibition")+
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", 
                               "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", 
           r.accuracy = 0.01, alternative = "two.sided")+
  theme(legend.direction = "horizontal")+
  scale_x_continuous(breaks = seq(0, 100, 20), 
                     limits=c(0, 100), 
                     labels = paste(c(0,20, 40, 60, 80, 100), "%"))+
  theme_classic(base_size = 14)
