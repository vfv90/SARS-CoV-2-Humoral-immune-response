#Title: "Humoral immune response towards SARS-CoV-2 variants of concern and endemic coronaviruses in urban and indigenous children from Colombia" 
#Authors: "Nathalie Fernandez"
#Date: 15.02.2023
#R version: 4.2.2
#Description: This script is based on the characteristics of the included indigenous population. 

# Packages
pacman::p_load("tidyverse", "MASS", "vcd", "asht", "irrCAC", "stats", "binom")

# Read database
indigenous <- read.csv("database_indigenous.csv", header = T, sep = "," )

##Part I. Description of characteristics of participants (Table 4)
#age is not included in the database for data protection reasons

##Positive and negatives
xtabs(~Classification,data=indigenous) #all participants 
xtabs(~Classification,data=indigenous)/sum(xtabs(~ Classification,data=indigenous))

##Sex
xtabs(~sex,data=indigenous) #all participants 
xtabs(~sex,data=indigenous)/sum(xtabs(~ sex,data=indigenous))
xtabs(~Classification + sex,data=indigenous) # reactive and non-ractive
xtabs(~Classification + sex,data=indigenous)/rowSums(xtabs(~Classification + sex,data=indigenous)) 
aux<-xtabs(~Classification + sex,data=indigenous)
fisher.test(aux) #Fisher test

##Part II. Seroprevalence by the two assays
#MULTICOV-AB
#positivity by MULTICOV-AB
xtabs(~Classification,data=indigenous)
xtabs(~Classification,data=indigenous)/sum(xtabs(~Classification,data=indigenous))

#seroprevalence using MULTICOV-AB
binom::binom.prop.test(x=sum(indigenous$Classification),n=nrow(indigenous))

#Adjustment seroprevalence MULTICOV-AB
asht::prevSeSp(28/82, 82, 181/205, 205, 72/72, 72)

#Euroimmun
#positivity by Euroimmun
xtabs(~ELISA_IgG_q,data=indigenous)
xtabs(~ELISA_IgG_q,data=indigenous)/sum(xtabs(~ELISA_IgG_q,data=indigenous))

#seroprevalence using Euroimmun
binom::binom.prop.test(x=24,n=nrow(indigenous))

#Adjustment seroprevalence Euroimmun (considering 4 borderlines as negatives)
asht::prevSeSp(24/82, 82, 164/205, 205, 70/72, 72)

##Part IV. Agreement between assays
#2x2 table
xtabs(~ Classification+ELISA_IgG_q, data=indigenous)

#Fleiss's kappa
irrCAC::fleiss.kappa.raw(indigenous[,c("Classification","ELISA_IgG_q")]) #coeff.val (conf.int) reported as text
