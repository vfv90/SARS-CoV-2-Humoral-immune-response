#Title: "Humoral immune response towards SARS-CoV-2 variants of concern and endemic coronaviruses in urban and indigenous children from Colombia"
#Authors: "Nathalie Fernandez"
#Date: 15.02.2023
#R version: 4.2.2
#Description: This script is based on the supplemental material of the manuscript.

# Packages
pacman::p_load("tidyverse", "lm", "glm", "MASS", "gtsummary", "eeptools", 
               "ggplot2", "L1pack", "vcd", "cowplot", "gridExtra", 
               "ggpubr", "RColorBrewer", "ggpmisc", "gridtext", "irrCAC")

# Read database
data <- read.csv("S1File March 2021-April 2021.csv", header = T, sep = "," ) #with samples collected from feb 2020 
data0 <- read.csv("Main manuscript March-April 2021.csv", header = T, sep = "," ) #with samples collected from March 2021 

# Factorization
library(gridExtra)
library(tidyverse)
library(dplyr)
library(rlang)
library(ggplot2)
library(ggpubr)
library(cli)
library(car)

data <- data %>% 
  mutate(sex = factor(sex, levels = c("1", "2"), labels = c("female", "male")),
         Population_group = factor(Population_group, levels = c("1", "2"), 
                                   labels = c("Urban children", 
                                              "Indigenous children")),
         ELISA_IgG_q = factor (ELISA_IgG_q, level = c("1", "0", "2"), 
                               labels = c("positive", "negative", "borderline")),
         Classification = factor (Classification, level = c("0", "1"),
                                  labels = c("negative", "positive")))

data0 <- data0 %>% 
  dplyr::mutate(sex = factor(sex, levels = c("1", "2"), labels = c("female", "male")),
                Population_group = factor(Population_group, levels = c("1", "2"), 
                                          labels = c("Urban children", 
                                                     "Indigenous children")),
                ELISA_IgG_q = factor (ELISA_IgG_q, level = c("1", "0", "2"), 
                                      labels = c("positive", "negative", "borderline")),
                Classification = factor (Classification, level = c("0", "1"),
                                         labels = c("negative", "positive"))) 

#Part I. Figures for SFile
# Figure S1
#a. Elisa titers and Multicov box plot
A <- ggplot(data = data,
            aes(x = ELISA_IgG_q,
                y = ELISA_IgG_S.CO, fill= Classification))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, 
               na.rm = TRUE, outlier.shape=NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = Classification), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  geom_hline(yintercept = 1.1, col = "gray70", linewidth = 0.5, alpha = 0.7)+
  geom_hline(yintercept = 0.8, col = "gray70", linewidth = 0.5, alpha = 0.7)+
  labs(y = "S1 IgG titer (ratio)",
       x = "Anti-SARS-CoV-2 IgG ELISA classification")+
  theme(legend.direction = "none")+
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2
IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00" , "negative" = "#999999"),
                    na.value = 1)+
  scale_y_log10() +
  theme_classic(base_size = 14)

A1 <-A + theme(legend.position = c(0.85, 0.85)) + labs(title = "A")

#b. S1 vrs Elisa
B <- ggplot(data = data,
       mapping = aes(x = SARS2.S1, y = ELISA_IgG_S.CO)) +
  geom_point(mapping = aes(fill= Classification), size = 2.5, shape=21, 
             alpha = 0.7, na.rm = TRUE)+
  geom_hline(yintercept = 1.1, col = "gray50", linewidth = 0.5, alpha = 0.7)+
  geom_hline(yintercept = 0.8, col = "gray50", linewidth = 0.5, alpha = 0.7)+
  labs(y = "S1 IgG titer (ratio)" ,
       x = "Normalized S1 IgG signal")+
  theme(legend.direction = "vertical")+
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2
IgG classification",
                    labels = c("Reactive", "Non-reactive"),
                    values = c("positive" = "#E69F00", "negative" = "#999999"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", label.y = 15, 
           r.accuracy = 0.01, alternative = "two.sided")+
  stat_smooth(method = "lm",formula = y ~ x, geom = "smooth", se=FALSE, 
              color="grey30", linewidth = 0.5, alpha = 0.7)+
  facet_grid(~Collection)+
  theme_classic(base_size = 14)

B1 <-B +  theme(legend.position = "none") + labs(title = "B")

grid.arrange(A1, B1, ncol=1, nrow=2, heights = c(1,1))

# Figure S2
# Program for heatmap 
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("ComplexHeatmap")

library(ComplexHeatmap)

library(circlize)

# Defining columns for the heatmap based on Endemic coronavirus (Seasonal pattern)
Endemic <- cbind(data$HCoV.OC43.S1, data$HCoV.HKU1.S1, 
                 data$HCoV.NL63.S1, data$HCoV.229E.S1)

# Saving data as a matrix
data3 <- as.matrix(Endemic)

# Saving name of the columns
colnames(data3) <- c("OC43","HKU1", "NL63", "229E")

###Endemcis by Population group
Heatmap(data3, 
             name = "hCoV S1 IgG signal", #title of legend
             split = data$Population_group, column_names_gp = gpar(fontsize = 10), 
             col = colorRamp2(c(0, 3, 6), c("lightblue", "steelblue", "steelblue4" )), show_row_names = FALSE, cluster_rows = FALSE,
             cluster_columns = FALSE, column_names_rot=0, 
             column_names_centered= TRUE, 
             row_title_rot = 0, row_title_gp = gpar(fontsize = 10))

# Figure S3

# Read database
pre <- read.csv("Pre_pandemic_control.csv", header = T, sep = ";" ) #control for pre-pandemic samples

# Factorization
pre <- pre %>% 
  dplyr::mutate(population_group = factor(population_group, levels = c("1", "2"), 
                                          labels = c("Urban children", 
                                                     "Indigenous children")),
                result_euro = factor (result_euro, level = c("0", "1"), 
                                      labels = c("negative", "positive")),
                result_multi = factor (result_multi, level = c("0", "1"),
                                         labels = c("negative", "positive"))) 

# define comparisons groups for figures
my_comparisons <- list( c("Urban children", "Indigenous children"))

# Panel for Euroimmun
A <- ggplot(data = pre,
            aes(x = result_euro,
                y = S1_IgG, fill= population_group))+
  geom_boxplot(position=position_dodge(0.8), alpha = 0.2, 
               na.rm = TRUE, outlier.shape=NA)+
  stat_boxplot(geom = "errorbar",
               width = 0.15, position=position_dodge(0.8))+
  geom_point(aes(fill = population_group), 
             size = 2, 
             shape = 21, 
             position = position_jitterdodge(jitter.height=0.1,
                                             jitter.width=0.25), na.rm = TRUE) +
  labs(y = "S1 IgG titer (ratio)",
       x = "Anti-SARS-CoV-2 IgG ELISA classification")+
  theme(legend.direction = "none")+
  scale_fill_manual(name = "Population group",
                    labels = c("Urban children", "Indigenous children"),
                    values = c("Urban children" = "#56B4E9", "Indigenous children" = "#F0E442"),
                    na.value = 1)+
  scale_y_log10() +
  theme_classic(base_size = 14)

A1 <-A + labs(title = "A")

#b. Panel for MULTICOV-AB
B <- ggplot(data = pre,
            mapping = aes(x = spike_igg, y = rbd_igg)) +
  geom_point(mapping = aes(fill= result_multi), size = 2.5, shape=21, 
             alpha = 0.7, na.rm = TRUE)+
  geom_vline(xintercept = 1, col = "gray10", linewidth = 0.5, alpha = 0.7)+
  geom_hline(yintercept = 1, col = "gray10", linewidth = 0.5, alpha = 0.7)+
  labs(y = "MULTICOV-AB RBD normalized IgG signal" ,
       x = "MULTICOV-AB Spike normalized IgG signal")+
  theme(legend.direction = "vertical")+
  scale_fill_manual(name = "MULTICOV-AB SARS-CoV-2
IgG classification",
                    labels = c("Non-reactive", "Reactive"),
                    values = c("negative" = "#999999", "positive" = "#E69F00"),
                    na.value = 1)+
  stat_cor(aes(label = ..r.label..), 
           method = "spearman", cor.coef.name = "rho", label.y = 4, 
           r.accuracy = 0.01, alternative = "two.sided")+
  facet_grid(~population_group)+
  scale_x_continuous(breaks = seq(0, 2, 0.5), 
                     limits=c(0, 2), 
                     labels = paste(c(0.0, 0.5, 1.0, 1.5, 2.0)))+
  theme_classic(base_size = 14)

B1 <-B +  labs(title = "B")

grid.arrange(A1, B1, ncol=1, nrow=2, heights = c(1,1))


#Part II. Table S8
table(data$Classification, data$ELISA_IgG_q)

#Fleiss's kappa
irrCAC::fleiss.kappa.raw(data[,c("Classification","ELISA_IgG_q")]) #coeff.val (conf.int) reported as text
