#Title: "Humoral immune response towards SARS-CoV-2 variants of concern and endemic coronaviruses in urban and indigenous children from Colombia" 
#Authors: "Nathalie Fernandez"
#Date: 15.02.2023
#R version: 4.2.2
#Description: This script is based on the characteristics of urban children from Bogot? only. 

# Packages
pacman::p_load("tidyverse", "MASS", "vcd", "asht", "irrCAC", "stats", "binom")

# Read database
mydata <- read.csv("database_urban_children_2021.csv", header = T, sep = "," , stringsAsFactors = F)

##Part I. Description of characteristics of participants (Table 2)
#age is not included in the database for data protection reasons

#age group
xtabs(~group_age,data=mydata) #all participants 
xtabs(~group_age,data=mydata)/sum(xtabs(~ group_age,data=mydata))
xtabs(~Classification + group_age,data=mydata) # reactive and non-ractive
xtabs(~Classification + group_age,data=mydata)/rowSums(xtabs(~Classification + group_age,data=mydata)) 
aux<-xtabs(~Classification + group_age,data=mydata)
fisher.test(aux) #Fisher test

#BMI
summary(mydata$BMI)
summary(mydata$BMI[mydata$Classification == 1])
summary(mydata$BMI[mydata$Classification == 0])

#logistic regression for BMI
igg_modelBMI <- glm(Classification ~ BMI, data = mydata, 
                    family = binomial(link = "logit"))
summary(igg_modelBMI)

exp(cbind(OR = coef(igg_modelBMI), confint(igg_modelBMI)))

#sex
xtabs(~sex,data=mydata) #all participants 
xtabs(~sex,data=mydata)/sum(xtabs(~ sex,data=mydata))
xtabs(~Classification + sex,data=mydata) # reactive and non-ractive
xtabs(~Classification + sex,data=mydata)/rowSums(xtabs(~Classification + sex,data=mydata)) 
aux<-xtabs(~Classification + sex,data=mydata)
fisher.test(aux) #Fisher test

#School type
xtabs(~school_type,data=mydata) #all participants
xtabs(~school_type,data=mydata)/sum(xtabs(~ school_type,data=mydata))  
xtabs(~Classification + school_type,data=mydata) # reactive and non-ractive
xtabs(~Classification + school_type,data=mydata)/rowSums(xtabs(~Classification + school_type,data=mydata))
aux<-xtabs(~Classification + school_type,data=mydata)
fisher.test(aux) #Fisher test

#Social security affiliation
xtabs(~subsidized,data=mydata) #all participants 
xtabs(~subsidized,data=mydata)/sum(xtabs(~subsidized,data=mydata)) 
xtabs(~Classification + subsidized,data=mydata) # reactive and non-ractive
xtabs(~Classification + subsidized,data=mydata)/rowSums(xtabs(~Classification + subsidized,data=mydata))
aux<-xtabs(~Classification + subsidized,data=mydata)
fisher.test(aux) #Fisher test

#Socioeconomical strata
xtabs(~se_stratum,data=mydata) #all participants 
xtabs(~se_stratum,data=mydata)/sum(xtabs(~se_stratum,data=mydata))
xtabs(~Classification + se_stratum,data=mydata) # reactive and non-ractive
xtabs(~Classification + se_stratum,data=mydata)/rowSums(xtabs(~Classification + se_stratum,data=mydata))
aux<-xtabs(~Classification + se_stratum,data=mydata[mydata$se_stratum!=8,])
fisher.test(aux) #Fisher test

#Income
xtabs(~income,data=mydata) #all participants 
xtabs(~income,data=mydata)/sum(xtabs(~income,data=mydata))
xtabs(~Classification + income,data=mydata) # reactive and non-ractive
xtabs(~Classification + income,data=mydata)/rowSums(xtabs(~Classification + income,data=mydata))
aux<-xtabs(~Classification + income,data=mydata[mydata$income<4,])
fisher.test(aux) #Fisher test

#Locality
xtabs(~locality,data=mydata) #all participants 
xtabs(~locality,data=mydata)/sum(xtabs(~locality,data=mydata))
xtabs(~Classification + locality,data=mydata) # reactive and non-ractive
xtabs(~Classification + locality,data=mydata)/rowSums(xtabs(~Classification + locality,data=mydata))
aux<-xtabs(~Classification + locality,data=mydata)
fisher.test(aux) #Fisher test

#Country
xtabs(~country,data=mydata) #all participants 
xtabs(~country,data=mydata)/sum(xtabs(~country,data=mydata))
xtabs(~Classification + country,data=mydata) # reactive and non-ractive
xtabs(~Classification + country,data=mydata)/rowSums(xtabs(~Classification + country,data=mydata))
aux<-xtabs(~Classification + country,data=mydata)
fisher.test(aux) #Fisher test

#PCR
xtabs(~participant_confirmed_COVID19,data=mydata) #all participants 
xtabs(~participant_confirmed_COVID19,data=mydata)/sum(xtabs(~participant_confirmed_COVID19,data=mydata))
xtabs(~Classification + participant_confirmed_COVID19,data=mydata) # reactive and non-ractive
xtabs(~Classification + participant_confirmed_COVID19,data=mydata)/rowSums(xtabs(~Classification + participant_confirmed_COVID19,data=mydata))
aux<-xtabs(~Classification + participant_confirmed_COVID19,data=mydata)
fisher.test(aux) #Fisher test

#Contact confirmed case
xtabs(~contact_probable_case_confirmed,data=mydata) #all participants 
xtabs(~contact_probable_case_confirmed,data=mydata)/sum(xtabs(~contact_probable_case_confirmed,data=mydata))
xtabs(~Classification + contact_probable_case_confirmed,data=mydata) # reactive and non-ractive
xtabs(~Classification + contact_probable_case_confirmed,data=mydata)/rowSums(xtabs(~Classification + contact_probable_case_confirmed,data=mydata))
aux<-xtabs(~Classification + contact_probable_case_confirmed,data=mydata[mydata$contact_probable_case_confirmed!=3,])
fisher.test(aux) #Fisher test

#Contact symptomatic case
xtabs(~contact_person_symptoms,data=mydata) #all participants 
xtabs(~contact_person_symptoms,data=mydata)/sum(xtabs(~contact_person_symptoms,data=mydata))
xtabs(~Classification + contact_person_symptoms,data=mydata) # reactive and non-ractive
xtabs(~Classification + contact_person_symptoms,data=mydata)/rowSums(xtabs(~Classification + contact_person_symptoms,data=mydata))
aux<-xtabs(~Classification + contact_person_symptoms,data=mydata)
fisher.test(aux) #Fisher test

#Family contact 
xtabs(~family_confirmed_COVID19,data=mydata) #all participants 
xtabs(~family_confirmed_COVID19,data=mydata)/sum(xtabs(~family_confirmed_COVID19,data=mydata))
xtabs(~Classification + family_confirmed_COVID19,data=mydata) # reactive and non-ractive
xtabs(~Classification + family_confirmed_COVID19,data=mydata)/rowSums(xtabs(~Classification + family_confirmed_COVID19,data=mydata))
aux<-xtabs(~Classification + family_confirmed_COVID19,data=mydata)
fisher.test(aux) #Fisher test

#HCW
xtabs(~HCW,data=mydata) #all participants 
xtabs(~HCW,data=mydata)/sum(xtabs(~HCW,data=mydata))
xtabs(~Classification + HCW,data=mydata) # reactive and non-ractive
xtabs(~Classification + HCW,data=mydata)/rowSums(xtabs(~Classification + HCW,data=mydata))
aux<-xtabs(~Classification + HCW,data=mydata)
fisher.test(aux) #Fisher test

#Trip 
xtabs(~trip_last_14days,data=mydata) #all participants 
xtabs(~trip_last_14days,data=mydata)/sum(xtabs(~trip_last_14days,data=mydata))
xtabs(~Classification + trip_last_14days,data=mydata) # reactive and non-ractive
xtabs(~Classification + trip_last_14days,data=mydata)/rowSums(xtabs(~Classification + trip_last_14days,data=mydata))
aux<-xtabs(~Classification + trip_last_14days,data=mydata[mydata$trip_last_14days!=3,])
fisher.test(aux) #Fisher test

#Acetaminophen use
xtabs(~acetaminophen,data=mydata) #all participants 
xtabs(~acetaminophen,data=mydata)/sum(xtabs(~acetaminophen,data=mydata))
xtabs(~Classification + acetaminophen,data=mydata) # reactive and non-ractive
xtabs(~Classification + acetaminophen,data=mydata)/rowSums(xtabs(~Classification + acetaminophen,data=mydata))
aux<-xtabs(~Classification + acetaminophen,data=mydata)
fisher.test(aux) #Fisher test

##Part II. Self-reported symptoms (Table 2)
# Change symptoms for a binary varaible

mydata$fever_yn <- ifelse(mydata$fever > 1,  c("yes"), c("no"))
mydata$nasal_congestion_yn <- ifelse(mydata$nasal_congestion > 1,  c("yes"), c("no"))                                                               
mydata$cough_yn <- ifelse(mydata$cough > 1,  c("yes"), c("no")) 
mydata$throat_pain_yn <- ifelse(mydata$throat_pain > 1,  c("yes"), c("no"))
mydata$loss_smell_taste_yn <- ifelse(mydata$loss_smell_taste > 1,  c("yes"), c("no"))
mydata$muscle_bone_pain_yn <- ifelse(mydata$muscle_bone_pain > 1,  c("yes"), c("no"))
mydata$nausea_yn <- ifelse(mydata$nausea > 1,  c("yes"), c("no"))
mydata$abdominal_pain_yn <- ifelse(mydata$abdominal_pain > 1,  c("yes"), c("no"))
mydata$diarrhea_yn <- ifelse(mydata$diarrhea > 1,  c("yes"), c("no"))

#Fever
xtabs(~fever,data=mydata) #all participants 
xtabs(~fever_yn,data=mydata)
xtabs(~fever_yn,data=mydata)/sum(xtabs(~fever_yn,data=mydata))
xtabs(~Classification + fever_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + fever_yn,data=mydata)/rowSums(xtabs(~Classification + fever_yn,data=mydata))
aux<-xtabs(~Classification + fever_yn,data=mydata)
fisher.test(aux) #Fisher test

#Nasal congestion
xtabs(~nasal_congestion,data=mydata) #all participants 
xtabs(~nasal_congestion_yn,data=mydata) 
xtabs(~nasal_congestion_yn,data=mydata)/sum(xtabs(~nasal_congestion_yn,data=mydata))
xtabs(~Classification + nasal_congestion_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + nasal_congestion_yn,data=mydata)/rowSums(xtabs(~Classification + nasal_congestion_yn,data=mydata))
aux<-xtabs(~Classification + nasal_congestion_yn,data=mydata)
fisher.test(aux) #Fisher test

#Cough
xtabs(~cough,data=mydata) #all participants 
xtabs(~cough_yn,data=mydata)
xtabs(~cough_yn,data=mydata)/sum(xtabs(~cough_yn,data=mydata))
xtabs(~Classification + cough_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + cough_yn,data=mydata)/rowSums(xtabs(~Classification + cough_yn,data=mydata))
aux<-xtabs(~Classification + cough_yn,data=mydata)
fisher.test(aux) #Fisher test

#Throat_pain
xtabs(~throat_pain,data=mydata) #all participants 
xtabs(~throat_pain_yn,data=mydata)
xtabs(~throat_pain_yn,data=mydata)/sum(xtabs(~throat_pain_yn,data=mydata))
xtabs(~Classification + throat_pain_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + throat_pain_yn,data=mydata)/rowSums(xtabs(~Classification + throat_pain_yn,data=mydata))
aux<-xtabs(~Classification + throat_pain_yn,data=mydata)
fisher.test(aux) #Fisher test

#Loss smell or taste
xtabs(~loss_smell_taste,data=mydata) #all participants 
xtabs(~loss_smell_taste_yn,data=mydata) 
xtabs(~loss_smell_taste_yn,data=mydata)/sum(xtabs(~loss_smell_taste_yn,data=mydata))
xtabs(~Classification + loss_smell_taste_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + loss_smell_taste_yn,data=mydata)/rowSums(xtabs(~Classification + loss_smell_taste_yn,data=mydata))
aux<-xtabs(~Classification + loss_smell_taste_yn,data=mydata)
fisher.test(aux) #Fisher test

#Muscle pain
xtabs(~muscle_bone_pain,data=mydata) #all participants 
xtabs(~muscle_bone_pain_yn,data=mydata)
xtabs(~muscle_bone_pain_yn,data=mydata)/sum(xtabs(~muscle_bone_pain_yn,data=mydata))
xtabs(~Classification + muscle_bone_pain_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + muscle_bone_pain_yn,data=mydata)/rowSums(xtabs(~Classification + muscle_bone_pain_yn,data=mydata))
aux<-xtabs(~Classification + muscle_bone_pain_yn,data=mydata)
fisher.test(aux) #Fisher test

#Nausea
xtabs(~nausea,data=mydata) #all participants 
xtabs(~nausea_yn,data=mydata)
xtabs(~nausea_yn,data=mydata)/sum(xtabs(~nausea_yn,data=mydata))
xtabs(~Classification + nausea_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + nausea_yn,data=mydata)/rowSums(xtabs(~Classification + nausea_yn,data=mydata))
aux<-xtabs(~Classification + nausea_yn,data=mydata)
fisher.test(aux) #Fisher test

#Abdominal pain
xtabs(~abdominal_pain,data=mydata) #all participants 
xtabs(~abdominal_pain_yn,data=mydata)
xtabs(~abdominal_pain_yn,data=mydata)/sum(xtabs(~abdominal_pain_yn,data=mydata))
xtabs(~Classification + abdominal_pain_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + abdominal_pain_yn,data=mydata)/rowSums(xtabs(~Classification + abdominal_pain_yn,data=mydata))
aux<-xtabs(~Classification + abdominal_pain_yn,data=mydata)
fisher.test(aux) #Fisher test

#Diarrea
xtabs(~diarrhea,data=mydata) #all participants 
xtabs(~diarrhea_yn,data=mydata)
xtabs(~diarrhea_yn,data=mydata)/sum(xtabs(~diarrhea_yn,data=mydata))
xtabs(~Classification + diarrhea_yn,data=mydata) # reactive and non-ractive
xtabs(~Classification + diarrhea_yn,data=mydata)/rowSums(xtabs(~Classification + diarrhea_yn,data=mydata))
aux<-xtabs(~Classification + diarrhea_yn,data=mydata)
fisher.test(aux) #Fisher test

##Part III. Seroprevalence by the two assays
#MULTICOV-AB
#positivity by MULTICOV-AB
xtabs(~Classification,data=mydata)
xtabs(~Classification,data=mydata)/sum(xtabs(~Classification,data=mydata))

#seroprevalence using MULTICOV-AB
binom::binom.prop.test(x=sum(mydata$Classification),n=nrow(mydata))

#Adjustment seroprevalence MULTICOV-AB
asht::prevSeSp(17/80, 80, 181/205, 205, 72/72, 72)

#Euroimmun
#positivity by Euroimmun
xtabs(~ELISA_IgG,data=mydata)
xtabs(~ELISA_IgG,data=mydata)/sum(xtabs(~ELISA_IgG,data=mydata))

#seroprevalence using Euroimmun
binom::binom.prop.test(x=sum(mydata$ELISA_IgG),n=nrow(mydata))

#Adjustment seroprevalence Euroimmun
asht::prevSeSp(18/80, 80, 164/205, 205, 70/72, 72)

##Part IV. Agreement between assays
#2x2 table
xtabs(~ Classification+ELISA_IgG, data=mydata)

#Fleiss's kappa
irrCAC::fleiss.kappa.raw(mydata[,c("Classification","ELISA_IgG")]) #coeff.val (conf.int) reported as text
